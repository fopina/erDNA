# erDNA Hello

This is an addon just to test the automation setup of the [erDNA repository](https://fopina.github.io/erDNA/)

Thanks to [@zag2me](https://github.com/zag2me/) for the [script.hello.world](https://github.com/zag2me/script.hello.world) this is forked from
